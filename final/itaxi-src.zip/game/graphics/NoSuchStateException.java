package game.graphics;

public class NoSuchStateException extends Exception 
{
	public NoSuchStateException()
	{
		super();
	}
	
	
	public NoSuchStateException(String message)
	{
		super(message);
	}
}